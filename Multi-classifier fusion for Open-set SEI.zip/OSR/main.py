import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn

import numpy as np
import h5py
from torch.utils.data import Dataset, DataLoader,TensorDataset
import os
import argparse
import sys

sys.path.append("../")
from openmax import compute_train_score_and_mavs_and_dists, fit_weibull, openmax
from Utils import adjust_learning_rate, progress_bar, Logger, mkdir_p, Evaluation
from Backbones.Signal import ResNet18_1d
import scipy.io as scio
'''
Code for Multi-classifier fusion for Open-set SEI
Published in Remote Sensing
Revised: 05/05/2022
Author: Yurui Zhao
'''

parser = argparse.ArgumentParser(description="PyTorch CIFAR10 Training")
parser.add_argument("--lr", default=0.001, type=float, help="learning rate")
parser.add_argument(
    "--resume",
    default=r"",
    type=str,
    metavar="PATH",
    help="path to latest checkpoint (default: none)",
)
parser.add_argument("--bs", default=100, type=int, help="batch size")
parser.add_argument("--es", default=100, type=int, help="epoch size")
parser.add_argument("--evaluate",
                    default=False,
                    type=bool,
                    help="Evaluate without training")
parser.add_argument(
    "--train_class_num", default=4, type=int, help="Classes used in training"
)
parser.add_argument(
    "--test_class_num", default=5, type=int, help="Classes used in testing"
)
parser.add_argument(
    "--includes_all_train_class",
    default=True,
    type=bool,
    help="If required all known classes included in testing",
)
# Parameters for weibull distribution fitting.
parser.add_argument(
    "--weibull_tail", default=20, type=int, help="Classes used in testing"
)
parser.add_argument(
    "--weibull_alpha", default=3, type=int, help="Classes used in testing"
)
parser.add_argument(
    "--weibull_threshold", default=0.9, type=float, help="Classes used in testing"
)
parser.add_argument(
    "--noise_db", default=None, type=int, help="Classes used in testing"
)


args = parser.parse_args()
args.SampleNum = 240
args.SampleLen = 128
args.FilePath = '../Dataset/Huanghua/HuanghuaAirPort_Len128.mat'
# Load data
# Format: X1:IQ (SampleNum,2,SampleLen)  X2:Spec (SampleNum,2,SampleLen) X3:AP (SampleNum,2,SampleLen) y:Label (1,SampleNum)
args.bs = 16
args.es = 100
args.lr = 0.002

# choose KKC and UUC devices
args.trainEmitterIndex = [0,1,2,3,4,5,6,7,8,9]
args.train_class_num = len(args.trainEmitterIndex)
args.openEmitterIndex = [10,11,12,13,14,15,16,17,18,19]
args.open_class_num = len(args.openEmitterIndex)
args.weibull_alpha = args.train_class_num
args.test_class_num = args.train_class_num + args.open_class_num # Test Data contain both KKC and UUC devices
args.includes_all_train_class = True


def printArgs():
    print("Args:")
    for k in args.__dict__:
        print(k + ": " + str(args.__dict__[k]))


def main():
    expName = 'exp_123'
    printArgs()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(device)
    start_epoch = 0
    # checkpoint
    args.checkpoint = "./checkpoints/Test_Huanghua_Fea/"+'_'+expName
    if not os.path.isdir(args.checkpoint):
        mkdir_p(args.checkpoint)
    '''Loading Data'''
    print("==> Preparing data..")
    train_class_num = args.train_class_num
    test_class_num = args.test_class_num
    unknow_class_num = args.open_class_num
    SampleNum = args.SampleNum
    FilePath = args.FilePath
    SampleLen = args.SampleLen

    DataFile = h5py.File(FilePath,'r')
    # X1:IQ X2:AF X3:AP
    AllDataSet1 = DataFile['X1'][:].transpose((2,1,0)) # IQ
    AllDataSet2 = DataFile['X2'][:].transpose((2,1,0)) # Spec.
    AllDataSet3 = DataFile['X3'][:].transpose((2,1,0)) # AP
    # y:Label
    AllDataLabel = DataFile['y'][:]-1

    DataSet1 = np.vstack(AllDataSet1[a*SampleNum:(a+1)*SampleNum,:,0:SampleLen] for a in args.trainEmitterIndex)
    DataSet2 = np.vstack(AllDataSet2[a*SampleNum:(a+1)*SampleNum,:,0:SampleLen] for a in args.trainEmitterIndex)
    DataSet3 = np.vstack(AllDataSet3[a*SampleNum:(a+1)*SampleNum,:,0:SampleLen] for a in args.trainEmitterIndex)
    DataLabel = AllDataLabel[0:train_class_num*SampleNum]

    '''Divid datasets for training, testing, and validating'''
    all_num = SampleNum * train_class_num
    perm = np.random.permutation(all_num)

    all_src1 =torch.FloatTensor(DataSet1[perm[0:all_num],:,0:SampleLen])
    all_src2 =torch.FloatTensor(DataSet2[perm[0:all_num],:,0:SampleLen])
    all_src3 =torch.FloatTensor(DataSet3[perm[0:all_num],:,0:SampleLen])

    all_trg = torch.FloatTensor(DataLabel[perm[0:all_num],:])

    all_dataset1 = TensorDataset(all_src1,all_trg)
    all_dataset2 = TensorDataset(all_src2,all_trg)
    all_dataset3 = TensorDataset(all_src3,all_trg)

    num_TrainData = int(all_num*0.8)
    num_TestData = int(all_num*0.1)
    num_ValData = all_num-num_TrainData-num_TestData

    train_data1, test_data1, val_data1 = torch.utils.data.random_split(all_dataset1, [num_TrainData, num_TestData, num_ValData],generator=torch.Generator().manual_seed(3407))
    train_data2, test_data2, val_data2 = torch.utils.data.random_split(all_dataset2, [num_TrainData, num_TestData, num_ValData],generator=torch.Generator().manual_seed(3407))
    train_data3, test_data3, val_data3 = torch.utils.data.random_split(all_dataset3, [num_TrainData, num_TestData, num_ValData],generator=torch.Generator().manual_seed(3407))

    # Add UUC into Test Datasets
    DataSetUnkown1 = np.vstack(AllDataSet1[b*SampleNum:(b+1)*SampleNum,:,0:SampleLen] for b in args.openEmitterIndex)
    DataSetUnkown2 = np.vstack(AllDataSet2[b*SampleNum:(b+1)*SampleNum,:,0:SampleLen] for b in args.openEmitterIndex)
    DataSetUnkown3 = np.vstack(AllDataSet3[b*SampleNum:(b+1)*SampleNum,:,0:SampleLen] for b in args.openEmitterIndex)
    DataLabelkown = AllDataLabel[train_class_num*SampleNum:test_class_num*SampleNum]
    DataLabelkown = np.ones((np.size(DataLabelkown,0),1))*train_class_num
    perm = np.random.permutation(unknow_class_num*SampleNum)
    unknown_src1 =torch.FloatTensor(DataSetUnkown1[perm[:],:,0:SampleLen])
    unknown_src2 =torch.FloatTensor(DataSetUnkown2[perm[:],:,0:SampleLen])
    unknown_src3 =torch.FloatTensor(DataSetUnkown3[perm[:],:,0:SampleLen])
    unknown_trg = torch.FloatTensor(DataLabelkown[perm[:],:])

    unknown_dataset1 = TensorDataset(unknown_src1,unknown_trg)
    unknown_dataset2 = TensorDataset(unknown_src2,unknown_trg)
    unknown_dataset3 = TensorDataset(unknown_src3,unknown_trg)

    num_Unknown = int(unknow_class_num*0.1*SampleNum)
    num_rest = unknow_class_num*SampleNum - num_Unknown
    unknown_data1, rest_data1 = torch.utils.data.random_split(unknown_dataset1, [num_Unknown, num_rest],generator=torch.Generator().manual_seed(3407))
    unknown_data2, rest_data2 = torch.utils.data.random_split(unknown_dataset2, [num_Unknown, num_rest],generator=torch.Generator().manual_seed(3407))
    unknown_data3, rest_data3 = torch.utils.data.random_split(unknown_dataset3, [num_Unknown, num_rest],generator=torch.Generator().manual_seed(3407))

    XData1 = []
    XData2 = []
    XData3 = []

    YLabel = []
    for X,y in test_data1:
        XData1.append(X.numpy())
        YLabel.append(y.numpy())
    for X,y in unknown_data1:
        XData1.append(X.numpy())
        YLabel.append(y.numpy())

    for X,y in test_data2:
        XData2.append(X.numpy())
    for X,y in unknown_data2:
        XData2.append(X.numpy())

    for X,y in test_data3:
        XData3.append(X.numpy())
    for X,y in unknown_data3:
        XData3.append(X.numpy())

    XData1 = np.array(XData1)
    XData2 = np.array(XData2)
    XData3 = np.array(XData3)

    YLabel = np.array(YLabel)

    all_test_data1 = TensorDataset(torch.FloatTensor(XData1),torch.FloatTensor(YLabel))
    all_test_data2 = TensorDataset(torch.FloatTensor(XData2),torch.FloatTensor(YLabel))
    all_test_data3 = TensorDataset(torch.FloatTensor(XData3),torch.FloatTensor(YLabel))

    trainloader1 = DataLoader(train_data1,batch_size=args.bs,shuffle=True)
    testloader1 = DataLoader(all_test_data1,batch_size=args.bs,shuffle=False)
    valloader1 = DataLoader(val_data1,batch_size=args.bs,shuffle=True)
    trainloader2 = DataLoader(train_data2,batch_size=args.bs,shuffle=True)
    testloader2 = DataLoader(all_test_data2,batch_size=args.bs,shuffle=False)
    valloader2 = DataLoader(val_data2,batch_size=args.bs,shuffle=True)
    trainloader3 = DataLoader(train_data3,batch_size=args.bs,shuffle=True)
    testloader3 = DataLoader(all_test_data3,batch_size=args.bs,shuffle=False)
    valloader3 = DataLoader(val_data3,batch_size=args.bs,shuffle=True)

    Energy_Noise = 0


    '''Model Build'''
    print("==> Building model..")
    net1 = ResNet18_1d(slice_size=DataSet1.shape[2],num_classes=args.train_class_num)
    net1 = net1.to(device)
    net2 = ResNet18_1d(slice_size=DataSet2.shape[2],num_classes=args.train_class_num)
    net2 = net2.to(device)
    net3 = ResNet18_1d(slice_size=DataSet3.shape[2],num_classes=args.train_class_num)
    net3 = net3.to(device)

    if device == "cuda":
        net1 = torch.nn.DataParallel(net1)
        net2 = torch.nn.DataParallel(net2)
        net3 = torch.nn.DataParallel(net3)
        cudnn.benchmark = True

    criterion = nn.CrossEntropyLoss()
    optimizer1 = optim.SGD(net1.parameters(), lr=args.lr,momentum=0.9, weight_decay=5e-4)
    optimizer2 = optim.SGD(net2.parameters(), lr=args.lr,momentum=0.9, weight_decay=5e-4)
    optimizer3 = optim.SGD(net3.parameters(), lr=args.lr,momentum=0.9, weight_decay=5e-4)

    for epoch1 in range(start_epoch, args.es):
        print("\nEpoch: %d   Learning rate: %f"% (epoch1 + 1, optimizer1.param_groups[0]["lr"]))
        adjust_learning_rate(optimizer1, epoch1, args.lr)  # 自适应学习率
        train_loss1, train_acc1 = train(net1, trainloader1, optimizer1, criterion, device,Energy_Noise)
    for epoch2 in range(start_epoch, args.es):
        print("\nEpoch: %d   Learning rate: %f"% (epoch2 + 1, optimizer2.param_groups[0]["lr"]))
        adjust_learning_rate(optimizer2, epoch2, args.lr)  # 自适应学习率
        train_loss2, train_acc2 = train(net2, trainloader2, optimizer2, criterion, device,Energy_Noise)
    for epoch3 in range(start_epoch, args.es):
        print("\nEpoch: %d   Learning rate: %f"% (epoch3 + 1, optimizer3.param_groups[0]["lr"]))
        adjust_learning_rate(optimizer3, epoch3, args.lr)  # 自适应学习率
        train_loss3, train_acc3 = train(net3, trainloader3, optimizer3, criterion, device,Energy_Noise)

    '''Test'''
    # Single Network Works
    eval_softmax1,eval_softmax_threshold1,eval_openmax1 = test(epoch1, net1, trainloader1, testloader1, criterion, device,Energy_Noise)
    eval_softmax2,eval_softmax_threshold2,eval_openmax2 = test(epoch2, net2, trainloader2, testloader2, criterion, device,Energy_Noise)
    eval_softmax3,eval_softmax_threshold3,eval_openmax3 = test(epoch3, net3, trainloader3, testloader3, criterion, device,Energy_Noise)

    trainFea1,trainLabel1,testFea1,testLabel1 = getFea(epoch1, net1, trainloader1, testloader1, criterion, device,Energy_Noise)
    trainFea2,trainLabel2,testFea2,testLabel2 = getFea(epoch2, net2, trainloader2, testloader2, criterion, device,Energy_Noise)
    trainFea3,trainLabel3,testFea3,testLabel3 = getFea(epoch3, net3, trainloader3, testloader3, criterion, device,Energy_Noise)
    # Multi-classifier Fusion
    # Algorithm-based methods
    for method in range(3):
        eval_softmax_combine,eval_softmax_threshold_combine,eval_openmax_combine = testCombine(epoch1,
                                                                                net1, trainloader1, testloader1,
                                                                                net2, trainloader2, testloader2,
                                                                                net3, trainloader3, testloader3,
                                                                                criterion, device,Energy_Noise,method)
        if method==0:
            eval_softmax4 = eval_softmax_combine
            eval_softmax_threshold4 = eval_softmax_threshold_combine
            eval_openmax4 = eval_openmax_combine
        elif method==1:
            eval_softmax5 = eval_softmax_combine
            eval_softmax_threshold5 = eval_softmax_threshold_combine
            eval_openmax5 = eval_openmax_combine
        else:
            eval_softmax6 = eval_softmax_combine
            eval_softmax_threshold6 = eval_softmax_threshold_combine
            eval_openmax6 = eval_openmax_combine
    # Voting-based methods
    eval_softmax_vote,eval_softmax_threshold_vote,eval_openmax_vote = testVote(epoch1,
                                                                                net1, trainloader1, testloader1,
                                                                                net2, trainloader2, testloader2,
                                                                                net3, trainloader3, testloader3,
                                                                                criterion, device,Energy_Noise)
    eval_softmax7 = eval_softmax_vote
    eval_softmax_threshold7 = eval_softmax_threshold_vote
    eval_openmax7 = eval_openmax_vote
    '''Save Results'''
    # Save Fea
    # scio.savemat('../Fea/Huanghua'+ expName+'.mat',
    #                  {'Softmax1': eval_softmax1, 'Softmax_Threshold1': eval_softmax_threshold1,'OpenMax1': eval_openmax1,
    #                   'Softmax2': eval_softmax2, 'Softmax_Threshold2': eval_softmax_threshold2,'OpenMax2': eval_openmax2,
    #                   'Softmax3': eval_softmax3, 'Softmax_Threshold3': eval_softmax_threshold3,'OpenMax3': eval_openmax3,
    #                   'trainFea1':trainFea1,'trainLabel1':trainLabel1,'testFea1':testFea1,'testLabel1':testLabel1,
    #                   'trainFea2':trainFea2,'trainLabel2':trainLabel2,'testFea2':testFea2,'testLabel2':testLabel2,
    #                   'trainFea3':trainFea3,'trainLabel3':trainLabel3,'testFea3':testFea3,'testLabel3':testLabel3,
    #                   })
    # Save Results
    scio.savemat('../Fea/Huanghua'+ expName+'.mat',
                     {'Softmax1': eval_softmax1, 'Softmax_Threshold1': eval_softmax_threshold1,'OpenMax1': eval_openmax1,
                      'Softmax2': eval_softmax2, 'Softmax_Threshold2': eval_softmax_threshold2,'OpenMax2': eval_openmax2,
                      'Softmax3': eval_softmax3, 'Softmax_Threshold3': eval_softmax_threshold3,'OpenMax3': eval_openmax3,
                      'Softmax4': eval_softmax4, 'Softmax_Threshold4': eval_softmax_threshold4,'OpenMax4': eval_openmax4,
                      'Softmax5': eval_softmax5, 'Softmax_Threshold5': eval_softmax_threshold5,'OpenMax5': eval_openmax5,
                      'Softmax6': eval_softmax6, 'Softmax_Threshold6': eval_softmax_threshold6,'OpenMax6': eval_openmax6,
                      'Softmax7': eval_softmax7, 'Softmax_Threshold7': eval_softmax_threshold7,'OpenMax7': eval_openmax7,
                      })


# Training
def train(net, trainloader, optimizer, criterion, device,Energy_Noise):
    net.train()
    train_loss = 0
    correct = 0
    total = 0
    for batch_idx, (inputs, targets) in enumerate(trainloader):
        inputs = inputs+torch.FloatTensor(np.random.normal(loc=0.0,scale=Energy_Noise,size=inputs.size()))
        inputs, targets = inputs.to(device), targets.long().to(device)
        optimizer.zero_grad()
        outputs = net(inputs)
        targets = targets.squeeze()
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()
        train_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()
        progress_bar(
            batch_idx,
            len(trainloader),
            "Loss: %.3f | Acc: %.3f%% (%d/%d)"
            % (train_loss / (batch_idx + 1), 100.0 * correct / total, correct, total),
        )
    return train_loss / (batch_idx + 1), correct / total


def test(epoch, net, trainloader, testloader, criterion, device, Energy_Noise):
    net.eval()
    test_loss = 0
    correct = 0
    total = 0
    best_F1 = 0
    scores, labels = [], []
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader):
            inputs = inputs+torch.FloatTensor(np.random.normal(loc=0.0,scale=Energy_Noise,size=inputs.size()))
            inputs, targets = inputs.to(device), targets.long().to(device)
            outputs = net(inputs)
            scores.append(outputs)
            labels.append(targets)
            progress_bar(batch_idx, len(testloader))

    scores = torch.cat(scores, dim=0).cpu().numpy()
    labels = torch.cat(labels, dim=0).cpu().numpy()

    scores = np.array(scores)[:, np.newaxis, :]
    labels = np.array(labels)

    labels[np.where(labels > args.train_class_num)] = args.train_class_num
    labels = np.squeeze(labels)
    labels = labels.tolist()

    print("Fittting Weibull distribution...")
    _, mavs, dists = compute_train_score_and_mavs_and_dists(
        args.train_class_num, trainloader, device, net
    )
    categories = list(range(0, args.train_class_num))
    weibull_model = fit_weibull(
        mavs, dists, categories, args.weibull_tail, "euclidean")

    pred_softmax, pred_softmax_threshold, pred_openmax = [], [], []
    score_softmax, score_openmax = [], []
    for score in scores:

        so, ss = openmax(weibull_model, categories, score, 0.5, args.weibull_alpha, "euclidean") # openmax_prob, softmax_prob
        # softmax
        pred_softmax.append(np.argmax(ss))
        # softmax-threshold
        pred_softmax_threshold.append(
            np.argmax(ss)
            if np.max(ss) >= args.weibull_threshold
            else args.train_class_num
        )
        # openmax
        pred_openmax.append(
            np.argmax(so)
            if np.max(so) >= args.weibull_threshold
            else args.train_class_num
        )
        score_softmax.append(ss)
        score_openmax.append(so)

    if not args.includes_all_train_class:
        score_softmax = None
        score_openmax = None


    print("Evaluation...")

    eval_softmax = Evaluation(pred_softmax, labels, score_softmax)
    eval_softmax_threshold = Evaluation(pred_softmax_threshold, labels, score_softmax)
    eval_openmax = Evaluation(pred_openmax, labels, score_openmax)
    torch.save(eval_softmax, os.path.join(args.checkpoint, "eval_softmax.pkl"))
    torch.save(eval_softmax_threshold,os.path.join(args.checkpoint, "eval_softmax_threshold.pkl"))
    torch.save(eval_openmax, os.path.join(args.checkpoint, "eval_openmax.pkl"))


    if eval_softmax.f1_measure > best_F1:
        best_F1 =  eval_softmax.f1_measure
        save_model(
            net, None, epoch, os.path.join(
                args.checkpoint, "best_model.pth")
        )
        torch.save(eval_openmax, os.path.join(args.checkpoint, "best_eval_openmax.pkl"))

    print(f"Softmax accuracy is %.3f" % (eval_softmax.accuracy))
    print(f"Softmax F1 is %.3f" % (eval_softmax.f1_measure))
    print(f"Softmax f1_macro is %.3f" % (eval_softmax.f1_macro))
    print(f"Softmax f1_macro_weighted is %.3f" %
          (eval_softmax.f1_macro_weighted))
    print(f"Softmax area_under_roc is %.3f" % (eval_softmax.area_under_roc))
    print(f"_________________________________________")

    print(f"SoftmaxThreshold accuracy is %.3f" %
          (eval_softmax_threshold.accuracy))
    print(f"SoftmaxThreshold F1 is %.3f" % (eval_softmax_threshold.f1_measure))
    print(f"SoftmaxThreshold f1_macro is %.3f" %
          (eval_softmax_threshold.f1_macro))
    print(
        f"SoftmaxThreshold f1_macro_weighted is %.3f"
        % (eval_softmax_threshold.f1_macro_weighted)
    )
    print(
        f"SoftmaxThreshold area_under_roc is %.3f"
        % (eval_softmax_threshold.area_under_roc)
    )
    print(f"_________________________________________")

    print(f"OpenMax accuracy is %.3f" % (eval_openmax.accuracy))
    print(f"OpenMax F1 is %.3f" % (eval_openmax.f1_measure))
    print(f"OpenMax f1_macro is %.3f" % (eval_openmax.f1_macro))
    print(f"OpenMax f1_macro_weighted is %.3f" %
          (eval_openmax.f1_macro_weighted))
    print(f"OpenMax area_under_roc is %.3f" % (eval_openmax.area_under_roc))
    print(f"_________________________________________")

    return eval_softmax,eval_softmax_threshold,eval_openmax
def testCombine(epoch1, net1, trainloader1, testloader1, net2, trainloader2, testloader2,net3, trainloader3, testloader3,criterion, device,Energy_Noise,method):
    net1.eval()
    net2.eval()
    net3.eval()

    test_loss = 0
    correct = 0
    total = 0
    best_F1 = 0
    scores1, labels1 = [], []
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader1):
            inputs = inputs+torch.FloatTensor(np.random.normal(loc=0.0,scale=Energy_Noise,size=inputs.size()))
            inputs, targets = inputs.to(device), targets.long().to(device)
            outputs = net1(inputs)
            scores1.append(outputs)
            labels1.append(targets)
            progress_bar(batch_idx, len(testloader1))
    scores1 = torch.cat(scores1, dim=0).cpu().numpy()
    labels1 = torch.cat(labels1, dim=0).cpu().numpy()
    scores1 = np.array(scores1)[:, np.newaxis, :]
    labels1 = np.array(labels1)
    labels1[np.where(labels1 > args.train_class_num)] = args.train_class_num
    labels1 = np.squeeze(labels1)
    labels1 = labels1.tolist()

    scores2, labels2 = [], []
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader2):
            inputs = inputs+torch.FloatTensor(np.random.normal(loc=0.0,scale=Energy_Noise,size=inputs.size()))
            inputs, targets = inputs.to(device), targets.long().to(device)
            outputs = net2(inputs)
            scores2.append(outputs)
            labels2.append(targets)
            progress_bar(batch_idx, len(testloader2))
    scores2 = torch.cat(scores2, dim=0).cpu().numpy()
    labels2 = torch.cat(labels2, dim=0).cpu().numpy()
    scores2 = np.array(scores2)[:, np.newaxis, :]
    labels2 = np.array(labels2)
    labels2[np.where(labels2 > args.train_class_num)] = args.train_class_num
    labels2 = np.squeeze(labels2)
    labels2 = labels2.tolist()

    scores3, labels3 = [], []
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader3):
            inputs = inputs+torch.FloatTensor(np.random.normal(loc=0.0,scale=Energy_Noise,size=inputs.size()))
            inputs, targets = inputs.to(device), targets.long().to(device)
            outputs = net3(inputs)
            scores3.append(outputs)
            labels3.append(targets)
            progress_bar(batch_idx, len(testloader3))
    scores3 = torch.cat(scores3, dim=0).cpu().numpy()
    labels3 = torch.cat(labels3, dim=0).cpu().numpy()
    scores3 = np.array(scores3)[:, np.newaxis, :]
    labels3 = np.array(labels3)
    labels3[np.where(labels3 > args.train_class_num)] = args.train_class_num
    labels3 = np.squeeze(labels3)
    labels3 = labels3.tolist()
    print("Fittting Weibull distribution...")
    categories = list(range(0, args.train_class_num))

    _, mavs1, dists1 = compute_train_score_and_mavs_and_dists(args.train_class_num, trainloader1, device, net1)
    weibull_model1 = fit_weibull(mavs1, dists1, categories, args.weibull_tail, "euclidean")

    _, mavs2, dists2 = compute_train_score_and_mavs_and_dists(args.train_class_num, trainloader2, device, net2)
    weibull_model2 = fit_weibull(mavs2, dists2, categories, args.weibull_tail, "euclidean")

    _, mavs3, dists3 = compute_train_score_and_mavs_and_dists(args.train_class_num, trainloader3, device, net3)
    weibull_model3 = fit_weibull(mavs3, dists3, categories, args.weibull_tail, "euclidean")

    '''根据score 预测输出'''
    pred_softmax, pred_softmax_threshold, pred_openmax = [], [], []
    score_softmax, score_openmax = [], []

    for index in range(len(labels1)):
        score1 = scores1[index,:]
        score2 = scores2[index,:]
        score3 = scores3[index,:]
        so1, ss1 = openmax(weibull_model1, categories, score1, 0.5, args.weibull_alpha, "euclidean")
        so2, ss2 = openmax(weibull_model2, categories, score2, 0.5, args.weibull_alpha, "euclidean")
        so3, ss3 = openmax(weibull_model3, categories, score3, 0.5, args.weibull_alpha, "euclidean")
        so1 = so1.reshape((-1,1))
        so2 = so2.reshape((-1,1))
        so3 = so3.reshape((-1,1))
        ss1 = ss1.reshape((-1,1))
        ss2 = ss2.reshape((-1,1))
        ss3 = ss3.reshape((-1,1))

        if method==0:
            so = (so1+so2+so3)/3
            ss = (ss1+ss2+ss3)/3
        elif method == 1:
            so = np.max(np.hstack([so1,so2,so3]),axis=1)
            ss = np.max(np.hstack([ss1,ss2,ss3]),axis=1)
        else:
            so = np.multiply(so1,so2,so3)
            ss = np.multiply(ss1,ss2,ss3)
        ss = np.squeeze(ss)
        so = np.squeeze(so)
        # Softmax
        pred_softmax.append(np.argmax(ss))
        # Softmax-threshold
        pred_softmax_threshold.append(np.argmax(ss) if np.max(ss) >= args.weibull_threshold else args.train_class_num)
        # Openmax
        pred_openmax.append(np.argmax(so) if np.max(so) >= args.weibull_threshold else args.train_class_num)

        score_softmax.append(ss)
        score_openmax.append(so)

    if not args.includes_all_train_class:
        score_softmax = None
        score_openmax = None


    print("Evaluation...")
    eval_softmax = Evaluation(pred_softmax, labels1, score_softmax)
    eval_softmax_threshold = Evaluation(pred_softmax_threshold, labels1, score_softmax)
    eval_openmax = Evaluation(pred_openmax, labels1, score_openmax)
    print(f"Softmax accuracy is %.3f" % (eval_softmax.accuracy))
    print(f"Softmax F1 is %.3f" % (eval_softmax.f1_measure))
    print(f"Softmax f1_macro is %.3f" % (eval_softmax.f1_macro))
    print(f"Softmax f1_macro_weighted is %.3f" %
          (eval_softmax.f1_macro_weighted))
    print(f"Softmax area_under_roc is %.3f" % (eval_softmax.area_under_roc))
    print(f"_________________________________________")

    print(f"SoftmaxThreshold accuracy is %.3f" %
          (eval_softmax_threshold.accuracy))
    print(f"SoftmaxThreshold F1 is %.3f" % (eval_softmax_threshold.f1_measure))
    print(f"SoftmaxThreshold f1_macro is %.3f" %
          (eval_softmax_threshold.f1_macro))
    print(
        f"SoftmaxThreshold f1_macro_weighted is %.3f"
        % (eval_softmax_threshold.f1_macro_weighted)
    )
    print(
        f"SoftmaxThreshold area_under_roc is %.3f"
        % (eval_softmax_threshold.area_under_roc)
    )
    print(f"_________________________________________")

    print(f"OpenMax accuracy is %.3f" % (eval_openmax.accuracy))
    print(f"OpenMax F1 is %.3f" % (eval_openmax.f1_measure))
    print(f"OpenMax f1_macro is %.3f" % (eval_openmax.f1_macro))
    print(f"OpenMax f1_macro_weighted is %.3f" %
          (eval_openmax.f1_macro_weighted))
    print(f"OpenMax area_under_roc is %.3f" % (eval_openmax.area_under_roc))
    print(f"_________________________________________")
    return eval_softmax,eval_softmax_threshold,eval_openmax

def testVote(epoch1, net1, trainloader1, testloader1, net2, trainloader2, testloader2,net3, trainloader3, testloader3,criterion, device,Energy_Noise):
    net1.eval()
    net2.eval()
    net3.eval()
    test_loss = 0
    correct = 0
    total = 0
    best_F1 = 0
    scores1, labels1 = [], []
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader1):
            inputs = inputs+torch.FloatTensor(np.random.normal(loc=0.0,scale=Energy_Noise,size=inputs.size()))
            inputs, targets = inputs.to(device), targets.long().to(device)
            outputs = net1(inputs)
            scores1.append(outputs)
            labels1.append(targets)
            progress_bar(batch_idx, len(testloader1))
    scores1 = torch.cat(scores1, dim=0).cpu().numpy()
    labels1 = torch.cat(labels1, dim=0).cpu().numpy()
    scores1 = np.array(scores1)[:, np.newaxis, :]
    labels1 = np.array(labels1)
    labels1[np.where(labels1 > args.train_class_num)] = args.train_class_num
    labels1 = np.squeeze(labels1)
    labels1 = labels1.tolist()

    scores2, labels2 = [], []
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader2):
            inputs = inputs+torch.FloatTensor(np.random.normal(loc=0.0,scale=Energy_Noise,size=inputs.size()))
            inputs, targets = inputs.to(device), targets.long().to(device)
            outputs = net2(inputs)
            scores2.append(outputs)
            labels2.append(targets)
            progress_bar(batch_idx, len(testloader2))
    scores2 = torch.cat(scores2, dim=0).cpu().numpy()
    labels2 = torch.cat(labels2, dim=0).cpu().numpy()
    scores2 = np.array(scores2)[:, np.newaxis, :]
    labels2 = np.array(labels2)
    labels2[np.where(labels2 > args.train_class_num)] = args.train_class_num
    labels2 = np.squeeze(labels2)
    labels2 = labels2.tolist()

    scores3, labels3 = [], []
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader3):
            inputs = inputs+torch.FloatTensor(np.random.normal(loc=0.0,scale=Energy_Noise,size=inputs.size()))
            inputs, targets = inputs.to(device), targets.long().to(device)
            outputs = net3(inputs)
            scores3.append(outputs)
            labels3.append(targets)
            progress_bar(batch_idx, len(testloader3))
    scores3 = torch.cat(scores3, dim=0).cpu().numpy()
    labels3 = torch.cat(labels3, dim=0).cpu().numpy()
    scores3 = np.array(scores3)[:, np.newaxis, :]
    labels3 = np.array(labels3)
    labels3[np.where(labels3 > args.train_class_num)] = args.train_class_num
    labels3 = np.squeeze(labels3)
    labels3 = labels3.tolist()

    print("Fittting Weibull distribution...")
    categories = list(range(0, args.train_class_num))

    _, mavs1, dists1 = compute_train_score_and_mavs_and_dists(args.train_class_num, trainloader1, device, net1)
    weibull_model1 = fit_weibull(mavs1, dists1, categories, args.weibull_tail, "euclidean")

    _, mavs2, dists2 = compute_train_score_and_mavs_and_dists(args.train_class_num, trainloader2, device, net2)
    weibull_model2 = fit_weibull(mavs2, dists2, categories, args.weibull_tail, "euclidean")

    _, mavs3, dists3 = compute_train_score_and_mavs_and_dists(args.train_class_num, trainloader3, device, net3)
    weibull_model3 = fit_weibull(mavs3, dists3, categories, args.weibull_tail, "euclidean")

    pred_softmax, pred_softmax_threshold, pred_openmax = [], [], []
    score_softmax, score_openmax = [], []
    pred_softmax1, pred_softmax_threshold1, pred_openmax1 = [], [], []
    score_softmax1, score_openmax1 = [], []
    pred_softmax2, pred_softmax_threshold2, pred_openmax2 = [], [], []
    score_softmax2, score_openmax2 = [], []
    pred_softmax3, pred_softmax_threshold3, pred_openmax3 = [], [], []
    score_softmax3, score_openmax3 = [], []

    for index in range(len(labels1)):
        score1 = scores1[index,:]
        score2 = scores2[index,:]
        score3 = scores3[index,:]
    # for score in scores:
        so1, ss1 = openmax(weibull_model1, categories, score1, 0.5, args.weibull_alpha, "euclidean")
        so2, ss2 = openmax(weibull_model2, categories, score2, 0.5, args.weibull_alpha, "euclidean")
        so3, ss3 = openmax(weibull_model3, categories, score3, 0.5, args.weibull_alpha, "euclidean")

        pred_softmax1.append(np.argmax(ss1))
        pred_softmax_threshold1.append(np.argmax(ss1) if np.max(ss1) >= args.weibull_threshold else args.train_class_num)
        pred_openmax1.append(np.argmax(so1) if np.max(so1) >= args.weibull_threshold else args.train_class_num)

        pred_softmax2.append(np.argmax(ss2))
        pred_softmax_threshold2.append(np.argmax(ss2) if np.max(ss2) >= args.weibull_threshold else args.train_class_num)
        pred_openmax2.append(np.argmax(so2) if np.max(so2) >= args.weibull_threshold else args.train_class_num)

        pred_softmax3.append(np.argmax(ss3))
        pred_softmax_threshold3.append(np.argmax(ss3) if np.max(ss3) >= args.weibull_threshold else args.train_class_num)
        pred_openmax3.append(np.argmax(so3) if np.max(so3) >= args.weibull_threshold else args.train_class_num)

        score_softmax1.append(ss1)
        score_openmax1.append(so1)
        score_softmax2.append(ss2)
        score_openmax2.append(so2)
        score_softmax3.append(ss3)
        score_openmax3.append(so3)
    for index in range(len(labels1)):
        count_softmax = np.bincount(np.array([pred_softmax1[index], pred_softmax2[index], pred_softmax3[index]]))
        score_softmaxTemp = np.zeros((np.size(score_softmax1[index],0),), dtype=np.float64)
        score_openmaxTemp = np.zeros((np.size(score_softmax1[index],0)+1,), dtype=np.float64)
        if np.max(count_softmax)==1:
            scoreTemp = np.array([ score_softmax1[index], score_softmax2[index], score_softmax3[index]])
            index_max = np.argmax(scoreTemp)
            if index_max >= 0 and index_max<np.size(score_softmax1[index],0):
                pred_softmaxTemp = pred_softmax1[index]
                score_softmaxTemp[pred_softmaxTemp] = score_softmax1[index][index_max]
            elif index_max>=np.size(score_softmax1[index],0) and index_max<2*np.size(score_softmax1[index],0):
                pred_softmaxTemp = pred_softmax2[index]
                index_max = index_max-np.size(score_softmax1[index],0)
                score_softmaxTemp[pred_softmaxTemp] = score_softmax2[index][index_max]
            else:
                pred_softmaxTemp = pred_softmax3[index]
                index_max = index_max-2*np.size(score_softmax1[index],0)
                score_softmaxTemp[pred_softmaxTemp] = score_softmax3[index][index_max]

        else:
            pred_softmaxTemp = np.argmax(count_softmax)
            score_softmaxTemp[pred_softmaxTemp] = 1

        count_softmax_threshold = np.bincount(np.array([pred_softmax_threshold1[index], pred_softmax_threshold2[index], pred_softmax_threshold3[index]]))
        if np.max(count_softmax_threshold)==1:
            scoreTemp = np.array([ score_softmax1[index], score_softmax2[index], score_softmax3[index]])
            index_max = np.argmax(scoreTemp)
            if index_max >= 0 and index_max<np.size(score_softmax1[index],0):
                pred_softmax_thresholdTemp = pred_softmax_threshold1[index]
            elif  index_max>=np.size(score_softmax1[index],0) and index_max<2*np.size(score_softmax1[index],0):
                pred_softmax_thresholdTemp = pred_softmax_threshold2[index]
                index_max = index_max-np.size(score_softmax1[index],0)
            else:
                pred_softmax_thresholdTemp = pred_softmax_threshold3[index]
                index_max = index_max-2*np.size(score_softmax1[index],0)
        else:
            pred_softmax_thresholdTemp = np.argmax(count_softmax_threshold)

        count_openmax = np.bincount(np.array([pred_openmax1[index], pred_openmax2[index], pred_openmax3[index]]))
        if np.max(count_openmax)==1:
            scoreTemp = np.array([ score_openmax1[index], score_openmax2[index], score_openmax3[index]])
            index_max = np.argmax(scoreTemp)
            if index_max >= 0 and index_max<np.size(score_openmax1[index],0):
                pred_openmaxTemp = pred_openmax1[index]
                score_openmaxTemp[pred_openmaxTemp] = score_openmax1[index][index_max]
            elif index_max>=np.size(score_openmax1[index],0) and index_max<2*np.size(score_openmax1[index],0):
                pred_openmaxTemp = pred_openmax2[index]
                index_max = index_max-np.size(score_openmax1[index],0)
                score_openmaxTemp[pred_openmaxTemp] = score_openmax2[index][index_max]
            else:
                pred_openmaxTemp = pred_openmax3[index]
                index_max = index_max-2*np.size(score_openmax1[index],0)
                score_openmaxTemp[pred_openmaxTemp] = score_openmax3[index][index_max]
        else:
            pred_openmaxTemp = np.argmax(count_openmax)
            score_openmaxTemp[pred_openmaxTemp] = 1


        pred_softmax.append(pred_softmaxTemp)
        pred_softmax_threshold.append(pred_softmax_thresholdTemp)
        pred_openmax.append(pred_openmaxTemp)

        score_softmax.append(score_softmaxTemp)
        score_openmax.append(score_openmaxTemp)





    print("Evaluation...")
    eval_softmax = Evaluation(pred_softmax, labels1,score_softmax)
    eval_softmax_threshold = Evaluation(pred_softmax_threshold, labels1,score_softmax)
    eval_openmax = Evaluation(pred_openmax, labels1,score_openmax)
    print(f"Softmax accuracy is %.3f" % (eval_softmax.accuracy))
    print(f"Softmax F1 is %.3f" % (eval_softmax.f1_measure))
    print(f"Softmax f1_macro is %.3f" % (eval_softmax.f1_macro))
    print(f"Softmax f1_macro_weighted is %.3f" %
          (eval_softmax.f1_macro_weighted))
    print(f"_________________________________________")

    print(f"SoftmaxThreshold accuracy is %.3f" %
          (eval_softmax_threshold.accuracy))
    print(f"SoftmaxThreshold F1 is %.3f" % (eval_softmax_threshold.f1_measure))
    print(f"SoftmaxThreshold f1_macro is %.3f" %
          (eval_softmax_threshold.f1_macro))
    print(
        f"SoftmaxThreshold f1_macro_weighted is %.3f"
        % (eval_softmax_threshold.f1_macro_weighted)
    )
    print(f"_________________________________________")

    print(f"OpenMax accuracy is %.3f" % (eval_openmax.accuracy))
    print(f"OpenMax F1 is %.3f" % (eval_openmax.f1_measure))
    print(f"OpenMax f1_macro is %.3f" % (eval_openmax.f1_macro))
    print(f"OpenMax f1_macro_weighted is %.3f" %
          (eval_openmax.f1_macro_weighted))
    print(f"_________________________________________")
    return eval_softmax,eval_softmax_threshold,eval_openmax

def getFea(epoch, net, trainloader, testloader, criterion, device,Energy_Noise):
    net.eval()

    scores, labels = [], []
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader):
            inputs = inputs + torch.FloatTensor(np.random.normal(loc=0.0, scale=Energy_Noise, size=inputs.size()))
            inputs, targets = inputs.to(device), targets.long().to(device)
            outputs = net(inputs)
            scores.append(outputs)
            labels.append(targets)
            progress_bar(batch_idx, len(testloader))
    scores = torch.cat(scores, dim=0).cpu().numpy()
    labels = torch.cat(labels, dim=0).cpu().numpy()
    testFea = np.array(scores)[:, np.newaxis, :]
    testLabel = np.array(labels)

    scores, labels = [], []
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(trainloader):
            inputs = inputs + torch.FloatTensor(np.random.normal(loc=0.0, scale=Energy_Noise, size=inputs.size()))
            inputs, targets = inputs.to(device), targets.long().to(device)
            outputs = net(inputs)
            scores.append(outputs)
            labels.append(targets)
            progress_bar(batch_idx, len(trainloader))
    scores = torch.cat(scores, dim=0).cpu().numpy()
    labels = torch.cat(labels, dim=0).cpu().numpy()
    trainFea = np.array(scores)[:, np.newaxis, :]
    trainLabel = np.array(labels)
    return trainFea, trainLabel, testFea, testLabel

def save_model(net, acc, epoch, path):
    print("Saving..")
    state = {
        "net": net.state_dict(),
        "testacc": acc,
        "epoch": epoch,
    }
    torch.save(state, path)


if __name__ == "__main__":
    main()
