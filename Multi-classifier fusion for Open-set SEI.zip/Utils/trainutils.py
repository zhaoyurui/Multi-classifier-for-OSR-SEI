import torch
from torch.autograd import Variable
from torch.utils.data import Dataset
import sys


def printArgs(args):
    print("Args:")
    for k in args.__dict__:
        print(k + ": " + str(args.__dict__[k]))


class myDataset(Dataset):
    def __init__(self, data, label, *args):
        self.data = data
        self.label = label

    def __getitem__(self, index):
        x = self.data[index]
        y = self.label[index]
        return x, y

    def __len__(self):
        return len(self.data)


def train(net, optimizer, criterion, loader, epoch, use_cuda, mode):
    print("Epoch: %d" % epoch)
    print("Mode: %s" % mode)

    if mode.upper() == 'TRAIN':
        net.train()
    elif mode.upper() == 'TEST':
        net.eval()

    train_loss = 0
    correct = 0
    total = 0
    for batch_idx, (inputs, targets) in enumerate(loader):
        if use_cuda:
            inputs, targets = inputs.cuda(), targets.cuda()
        optimizer.zero_grad()
        inputs, targets = Variable(inputs), Variable(targets)
        outputs = net(inputs)
        loss = criterion(outputs, targets)

        if mode.upper() == 'TRAIN':
            loss.backward()
            optimizer.step()
        elif mode.upper() == 'TEST':
            pass
        else:
            print('mode err %s' % mode)

        train_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        total += targets.size(0)
        correct += predicted.eq(targets.data).cpu().sum()
        sys.stdout.write(
            "Loss: %.3f | Acc: %.3f%% (%d/%d)"
            % (train_loss / (batch_idx + 1), 100.0 * correct / total, correct, total)
        )
        sys.stdout.write("\r")
        sys.stdout.flush()
    sys.stdout.write("\n")
    sys.stdout.flush()

    acc = 100.0 * correct / total
    return acc, train_loss/(batch_idx + 1)
