This code is for 'Multi-classifier Fusion for Open-set Specific Emitter Identification'.

Paper is published in Remote Sensing.

Author: Yurui Zhao

Email: zhaoyurui@nudt.edu.cn

Affiliation: College of Electronic Science and Technology, National University  of Defense Technology  

The main code is in './OSR/main.py'

If there is any problem, please don't hesitate to contact me. 